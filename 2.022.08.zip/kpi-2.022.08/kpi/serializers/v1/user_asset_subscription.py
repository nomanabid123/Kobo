# coding: utf-8
from kpi.serializers.v2.user_asset_subscription import (
    UserAssetSubscriptionSerializer as UserAssetSubscriptionSerializerV2
)


class UserAssetSubscriptionSerializer(UserAssetSubscriptionSerializerV2):

    pass

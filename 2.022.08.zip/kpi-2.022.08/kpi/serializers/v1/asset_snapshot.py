# coding: utf-8
from kpi.serializers.v2.asset_snapshot import AssetSnapshotSerializer as AssetSnapshotSerializerV2


class AssetSnapshotSerializer(AssetSnapshotSerializerV2):

    pass

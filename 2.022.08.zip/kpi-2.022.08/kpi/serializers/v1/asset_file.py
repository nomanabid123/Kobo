# coding: utf-8
from kpi.serializers.v2.asset_file import \
    AssetFileSerializer as AssetFileSerializerV2


class AssetFileSerializer(AssetFileSerializerV2):

    pass

# coding: utf-8
from django.apps import AppConfig


class SuperuserStatsAppConfig(AppConfig):

    name = 'kobo.apps.superuser_stats'
    verbose_name = 'Superuser Stats'
    label = 'superuser_stats'
